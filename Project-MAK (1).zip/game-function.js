document.write("hey u comin to the party");

setTimeout(() => {prompt("Thoughtbubble: do I really want to go? I mean its 4pm, which i guess it pretty early...for my standards. Yes or No?"); }, 5000)



