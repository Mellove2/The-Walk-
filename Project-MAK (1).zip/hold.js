
const answer_yes = [yes, y, Yes, Y, YES]
const answer_no = [no, n, No, N, NO]

Let ans1 = yes
  if (ans1 = answer_yes){
    document.write("hi tee hee")
  }
    