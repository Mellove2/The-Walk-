from browser import document, html

answer_yes = ["Yes", "Y", "yes", "y"]
answer_no = ["No", "N", "no", "n"]

print("""
Welcome... Can you survive?

You got lost in a forest and dont know how you got to where you are.

Would you like to wander around? (Yes / No)
""")

ans1 = input(">>")

if ans1 in answer_yes:
  print(
    "\nAfter looking around for a bit you find a small cabin that gives off a bad vibe... do you go in? (Yes / No)\n"
  )

  ans2 = input(">>")

  if ans2 in answer_yes:
    print(
      "\nYou went in a found simple tools that ensures survival and good that was lying around, you see some food laying... Do you eat it?"
    )

  ans4 = input(">>")

  if ans4 in answer_yes:
    print("The food was drugged and you fell asleep")

  elif ans2 in answer_no:
    print("\nYou helped a thief. Now, go to Jail. GAME OVER")

  else:
    print("\nYou typed the wrong input. GOODBYE!")

elif ans1 in answer_no:
  print(
    "\nNow, he is trying to kill you. Will, you knock him down? (Yes / No)\n")

  ans1a = input(">>")

  if ans1a in answer_yes:
    print(
      "\nCongrats! He was a thief & You helped the police to catch him with your bravery."
    )

  elif ans1a in answer_no:
    print("\nSorry! You are dead. He was a thief & He killed you. GAME OVER")

  else:
    print("\nYou typed the wrong input. GOODBYE!")

else:
  print("\nYou typed the wrong input. GOODBYE!")